using System.Linq;
using GoldenPear.BLL.CourseServices;
using GoldenPear.BLL.StudentServices;
using GoldenPear.BOL.Models;
using GoldenPear.DAL.DbContext;
using GoldenPear.DAL.UnitOfWork;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GoldenPear.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        private IStudent _studentService;
        private ICourse _courseService;


        [TestMethod]
        public void StudentTestMethod()
        {
            var db = new TestDbContext();
            IUnitOfWork uow = new UnitOfWork(db);
            _studentService = new StudentServices(uow, null);
            var student = _studentService.GetStudent(1);
            Assert.IsTrue(student.FirstName == "John");
        }

        [TestMethod]
        public void StudentCourseListTestMethod()
        {
            var db = new TestDbContext();
            IUnitOfWork uow = new UnitOfWork(db);
            _courseService = new CourseServices(uow);
            _studentService = new StudentServices(uow, _courseService);
            var student = _studentService.GetStudentCourses(1);
            Assert.IsTrue(EnumerableExtensions.Any(student));
        }

        [TestMethod]
        public void CourseListTestMethod()
        {
            var db = new TestDbContext();
            IUnitOfWork uow = new UnitOfWork(db);
            _courseService = new CourseServices(uow);
            var course= _courseService.GetCourseList();
            Assert.IsTrue(EnumerableExtensions.Any(course));
        }

        [TestMethod]
        public void AddCourseTestMethod()
        {
            var db = new TestDbContext();
            IUnitOfWork uow = new UnitOfWork(db);
            _courseService = new CourseServices(uow);
            var newCourse = new CourseList
            {
                CourseName = "DeleteMe"
            };
            var course= _courseService.AddCourse(newCourse);
            Assert.IsTrue(course > 0);
        }
        
        [TestMethod]
        public void DeleteCourseTestMethod()
        {
            var db = new TestDbContext();
            IUnitOfWork uow = new UnitOfWork(db);
            _courseService = new CourseServices(uow);
            var newCourse = _courseService.GetCourseList().FirstOrDefault(x => x.CourseName == "DeleteMe");
            Assert.IsTrue(newCourse != null && newCourse.CourseListId > 0);
            var course= _courseService.DeleteCourse(newCourse.CourseListId);
            Assert.IsTrue(course > 0);
        }
    }
}
