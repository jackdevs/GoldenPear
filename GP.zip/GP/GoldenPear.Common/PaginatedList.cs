﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GoldenPear.Common
{
  
    /// <summary>
    /// Returns a paginated list IEnumerable list of TEntity
    /// </summary>
    /// <property name="PageIndex"></property>
    /// <property name="TotalPages"></property>
    /// <property name="TotalItems"></property>
    /// <returns>paginated list</returns>
    public class PaginatedList<T> : List<T>
    {
        public int PageIndex { get; private set; }
        public int TotalPages { get; private set; }
        public int TotalItems { get; private set; }

        public PaginatedList(IEnumerable<T> items, int count, int pageIndex, int pageSize)
        {
            PageIndex = pageIndex;
            TotalPages = (int)Math.Ceiling(count / (double)pageSize);
            TotalItems = count;
            AddRange(items);
        }

        public bool HasPreviousPage
        {
            get
            {
                return (PageIndex > 1);
            }
        }

        public bool HasNextPage
        {
            get
            {
                return (PageIndex < TotalPages);
            }
        }

        public int Total
        {
            get
            {
                return TotalItems; 
            }
        }

 

        public static PaginatedList<T> Create(IQueryable<T> source, int pageIndex, int pageSize)
        {
            var count = source.Count();
            var items = source.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            return new PaginatedList<T>(items, count, pageIndex, pageSize);
        }
    }
}
