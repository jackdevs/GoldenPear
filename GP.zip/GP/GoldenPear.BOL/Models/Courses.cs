﻿namespace GoldenPear.BOL.Models
{
    public class Courses: Base
    {
        public int CourseId { get; set; }
        public int StudentId { get; set; }
        public int CourseListId { get; set; }

    }
}
