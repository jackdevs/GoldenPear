﻿using System.ComponentModel.DataAnnotations;

namespace GoldenPear.BOL.Models
{
    public class CourseList
    {
        public int CourseListId { get; set; }
        [Required(ErrorMessage = "Course name is required")]
        public string CourseName { get; set; }
    }
}
