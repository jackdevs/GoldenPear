﻿using System.ComponentModel.DataAnnotations;

namespace GoldenPear.BOL.Models
{
   public class Students : Base
    {
        public int StudentId { get; set; }
        [Required(ErrorMessage = "First name is required")]
        public string FirstName { get; set; }
      
        [Required(ErrorMessage = "Last name is required")]
        public string LastName { get; set; }

        public string Grade { get;set; }
        public string Major { get; set; }

    }
}
