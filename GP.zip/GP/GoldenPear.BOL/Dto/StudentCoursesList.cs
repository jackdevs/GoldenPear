﻿namespace GoldenPear.BOL.Dto
{
    public class StudentCourseList
    {
        public int StudentId { get; set; }
        public int CourseListId { get; set; }
        public bool Selected { get;set; }
        public string CourseName { get; set; }
    }
}
