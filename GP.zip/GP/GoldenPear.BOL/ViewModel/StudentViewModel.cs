﻿using System.Collections.Generic;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.Common;

namespace GoldenPear.BOL.ViewModel
{
   public class StudentViewModel
    {
        public Students Student { get; set; } 

        public PaginatedList<Students> Students { get; set; }

        public PaginatedList<Courses> Courses{ get; set; }
        public IEnumerable<CourseList> CourseList{ get; set; } 

        public IEnumerable<StudentCourseList> StudentCoursesList { get; set; }
    }
}
