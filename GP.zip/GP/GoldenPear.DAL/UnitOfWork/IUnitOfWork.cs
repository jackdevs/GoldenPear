﻿using GoldenPear.BOL.Models;
using GoldenPear.DAL.Repository;

namespace GoldenPear.DAL.UnitOfWork
{
    public interface IUnitOfWork
    {
        IRepository<Students> StudentRepository { get; }
        IRepository<Courses> CourseRepository { get; }

        IRepository<CourseList> CourseListRepository { get; }

      


        void Save();
    }
}
