﻿using GoldenPear.BOL.Models;
using GoldenPear.DAL.Factory;
using GoldenPear.DAL.Repository;

namespace GoldenPear.DAL.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {

        private readonly Microsoft.EntityFrameworkCore.DbContext _dbContext;

        public UnitOfWork(Microsoft.EntityFrameworkCore.DbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IRepository<Students> StudentRepository
        {
            get
            {
                return RepositoryFactory.GetRepositoryInstance<Students, Repository<Students>>(_dbContext);
            }
        }

        public IRepository<Courses> CourseRepository
        {
            get
            {
                return RepositoryFactory.GetRepositoryInstance<Courses, Repository<Courses>>(_dbContext);
            }
        }

        public IRepository<CourseList> CourseListRepository
        {
            get { return RepositoryFactory.GetRepositoryInstance<CourseList, Repository<CourseList>>(_dbContext); }
        }

       

        public void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
