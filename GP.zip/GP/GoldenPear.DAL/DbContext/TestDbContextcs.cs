﻿using GoldenPear.BOL.Models;
using Microsoft.EntityFrameworkCore;

namespace GoldenPear.DAL.DbContext
{
    public partial class TestDbContext : Microsoft.EntityFrameworkCore.DbContext
    {
        public TestDbContext()
        {
        }

        public TestDbContext(DbContextOptions<TestDbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Students> Students { get; set; }
        public virtual DbSet<Courses> Courses { get; set; }

        public virtual DbSet<CourseList> CourseList { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(
                    "Server=CMTOWDGMOSSQL01;Database=TestDb;Integrated Security=true;MultipleActiveResultSets=true");
                optionsBuilder.EnableSensitiveDataLogging();
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Students>(entity =>
            {
                entity.HasKey(e => e.StudentId)
                    .ForSqlServerIsClustered();

                entity.ToTable("Students");

                entity.HasIndex(e => new {e.LastName})
                    .HasName("IX_Students_LastName");

                entity.Property(e => e.StudentId).HasDefaultValueSql("(newid())");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Grade)
                    .HasMaxLength(50);
                
                entity.Property(e => e.Major)
                    .HasMaxLength(50);
                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50);

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Courses>(entity =>
            {
                entity.HasKey(e => e.CourseId)
                    .ForSqlServerIsClustered();

                entity.ToTable("Courses");

            

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
                entity.Property(e => e.CreatedBy)
                    .HasMaxLength(50);

                entity.Property(e => e.DateUpdated)
                    .HasColumnType("datetime");
                entity.Property(e => e.UpdatedBy)
                    .HasMaxLength(50);
            });

        }
    }
}


