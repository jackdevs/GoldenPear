﻿using System;
using GoldenPear.DAL.Repository;

namespace GoldenPear.DAL.Factory
{
    public class RepositoryFactory {
        public static TRepository GetRepositoryInstance<T, TRepository>(params object[] args) where TRepository : IRepository<T> {
            return (TRepository)Activator.CreateInstance(typeof(TRepository), args);
        }
    }
}
