﻿$(function () {
  
    $("body").on("click",".modal-link",
        function(e) {
            e.preventDefault();
            $.get($(this).data("targeturl"),
                function(data) {

                    $('<div class="modal fade" id="myModal">' +
                        '<div class="modal-dialog">' +
                        '<div class="modal-content">' +
                        '<div class="modal-header">' +
                        '<button type="button" class="close" data-dismiss="modal" onClick="location.reload();" aria-label="Close">' +
                        '<span aria-hidden="true">&times;</span>' +
                        '</button>' +
                        '<h3 class="modal-title">Student Details</h3>' +
                        '</div>' +
                        '<div class="modal-body">' +
                        data +
                        '</div>' +
                        '<div class="modal-footer">' +
                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>').modal();

                });
        });
});

function UpdateStudent() {
        var studentObject = new Object();
        studentObject.StudentId = $("#StudentId").val();
        studentObject.FirstName= $("#FirstName").val();
        studentObject.LastName = $("#LastName").val();
        studentObject.Grade = $("#Grade").val().trim();
        studentObject.Major = $("#Major").val();
    if ($("#StudentId").val() === 0) {
        studentObject.DateCreated = '04/04/2019';
        studentObject.CreatedBy = 'Mark';
    } else {
        studentObject.DateUpdated = '04/04/2019';
        studentObject.UpdatedBy = 'Mark';
    }
   

    $.ajax({
            type: "POST",
            url: window.student.Urls.UpdateStudent,
         
            data: JSON.stringify(studentObject) ,  
            contentType: "application/json; charset=utf-8",  
            dataType: "json",  
            success: function(response) {  
                if (response) {  
                    if (response.value) {
                        if (response.value.success === true) {

                            UpdateStudentCourses(response.value.studentId);
                           
                        } else {
                            var modelErrors = [];
                            for (var i = 0; i < response.value.errors.length; i++) {
                                modelErrors.push(response.value.errors[i].errors[0].errorMessage);
                            }
                            if (modelErrors.length > 0) {
                                $("#modalMessage").modal("show");
                                document.getElementById("divMessage").appendChild(CreateUL(modelErrors));
                            }
                        }
                    }
                    else {
                        alert("There was an unexpected error updating / adding this record");  
                    }
                } else {  
                    alert("There was an unexpected error updating / adding this record");  
                }  
            },
            failure: function(response) {  
                alert("There was an unexpected error updating / adding this record");  
            },  
            error: function(response) {  
                alert("There was an unexpected error updating / adding this record");  
            }  
        });  
    }
function UpdateStudentCourses(studentId) {

      var courseList = ProcessCourseList(studentId);
      if (courseList && courseList.length > 0) {

          var studentCourses = JSON.stringify(courseList);
          
          $.ajax({
              type: "POST",
              url: window.student.Urls.UpdateStudentCourses,
              data: studentCourses,
              contentType: "application/json; charset=utf-8",
              dataType: "json",
              beforeSend: function() {

              },
              success: function(response) {
                  if (response) {
                      if (response.value) {
                          if (response.value.success === true) {
                              alert(response.value.studentName + " updated successfully.");
                          } else {
                              var modelErrors = [];
                              for (var i = 0; i < response.value.errors.length; i++) {
                                  modelErrors.push(response.value.errors[i].errors[0].errorMessage);
                              }
                              if (modelErrors.length > 0) {
                                  $("#modalMessage").modal("show");
                                  document.getElementById("divMessage").appendChild(CreateUL(modelErrors));
                              }
                          }
                      } else {
                          $("#modalWaitMessage").modal("hide");
                          alert("Something went wrong");
                      }
                  } else {
                      $("#modalWaitMessage").modal("hide");
                      alert("Something went wrong");
                  }
              },
              failure: function(response) {
                  $("#modalWaitMessage").modal("hide");
                  alert("There was an unexpected error");
              },
              error: function(response) {
                  $("#modalWaitMessage").modal("hide");
                  alert("There was an unexpected error");
              }
          });
      }
  }

function DeleteStudent() {

    var proceed = confirm("You are about to delete this student. Continue?");
    if (proceed) {
        var studentObject = new Object();
        studentObject.StudentId = $("#StudentId").val();

        $.ajax({
            type: "POST",
            url: window.student.Urls.DeleteStudent,
            data: JSON.stringify(studentObject),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(response) {
                if (response) {
                    if (response.value) {
                        if (response.value.success === true) {
                            alert("Student deleted successfully.");
                            location.reload();
                        }
                    } else {
                        alert("Something went wrong");
                    }
                } else {
                    alert("Something went wrong");
                }
            },
            failure: function(response) {
                alert("There was an unexpected error");
            },
            error: function(response) {
                alert("There was an unexpected error");
            }
        });
    }
}


function CloseMessage() {
    $("#modalMessage").modal("hide");
}

function CreateUL(array) {
    // Create the list element:
    var list = document.createElement("ul");
    for (var i = 0; i < array.length; i++) {
        // Create the list item:
        var item = document.createElement("li");
        // Set its contents:
        item.appendChild(document.createTextNode(array[i]));
        // Add it to the list:
        list.appendChild(item);
    }

    // Finally, return the constructed list:
    return list;
}

function ProcessCourseList(id) {

  
    var selected = "";
    var studentId = "";
    var courseListId = "";
    var courseName = "";
    var viewDataCourses = { courses : [] };

    var jsonData = {};
    var listItems = document.getElementById("studentCourseList").getElementsByTagName("li");

    if (listItems) {
        for (var i = 0; i < listItems.length; i++) {
            var node = listItems[i];
            if (node) {
                for (var j = 0; j < node.childElementCount; j++) {
                    var child = node.children[j];
                    if (child) {
                        if (child.id) {
                            if (child.id.toLowerCase() === "selected") {
                                selected = child.checked;
                            }
                            if (child.id.toLowerCase() === "studentid") {
                                if (id > 0) {
                                    studentId = id;
                                } else {
                                    studentId = child.value;
                                }
                            }
                            if (child.id.toLowerCase() === "coursename") {
                                courseName = child.textContent;
                            }
                            if (child.id.toLowerCase() === "courselistid") {
                                courseListId = child.value;
                            }
                        }
                    }
                }
                jsonData["StudentId"] = studentId;
                jsonData["courseListId"] = courseListId;
                jsonData["Selected"] = selected;
                jsonData["CourseName"] = courseName;
               
            }
            viewDataCourses.courses.push(jsonData);
            jsonData = {};
        }
    }
    return viewDataCourses.courses;
}
