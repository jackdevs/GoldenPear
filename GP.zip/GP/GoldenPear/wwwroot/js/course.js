﻿$(function () {
  
    $("body").on("click",".modal-link",
        function(e) {
            e.preventDefault();
            $.get($(this).data("targeturl"),
                function(data) {

                    $('<div class="modal fade" id="myModal">' +
                        '<div class="modal-dialog">' +
                        '<div class="modal-content">' +
                        '<div class="modal-header">' +
                        '<button type="button" class="close" data-dismiss="modal" onClick="location.reload();" aria-label="Close">' +
                        '<span aria-hidden="true">&times;</span>' +
                        '</button>' +
                        '<h3 class="modal-title">Course Details</h3>' +
                        '</div>' +
                        '<div class="modal-body">' +
                        data +
                        '</div>' +
                        '<div class="modal-footer">' +
                        '</div>' +
                        '</div>' +
                        '</div>' +
                        '</div>').modal();

                });
        });
});

function UpdateCourse() {
        var courseObject = new Object();
        courseObject.CourseListId = $("#CourseListId").val();
        courseObject.CourseName= $("#CourseName").val();
   

    $.ajax({
            type: "POST",
            url: window.course.Urls.UpdateCourse,
         
            data: JSON.stringify(courseObject) ,  
            contentType: "application/json; charset=utf-8",  
            dataType: "json",  
            success: function(response) {  
                if (response) {  
                    if (response.value) {
                        if (response.value.success === true) {
                            alert(response.value.courseName + " updated successfully.");
                           
                        } else {
                            var modelErrors = [];
                            for (var i = 0; i < response.value.errors.length; i++) {
                                modelErrors.push(response.value.errors[i].errors[0].errorMessage);
                            }
                            if (modelErrors.length > 0) {
                                $("#modalMessage").modal("show");
                                document.getElementById("divMessage").appendChild(CreateUL(modelErrors));
                            }
                        }
                    }
                    else {
                        alert("There was an unexpected error updating / adding this record");  
                    }
                } else {  
                    alert("There was an unexpected error updating / adding this record");  
                }  
            },
            failure: function(response) {  
                alert("There was an unexpected error updating / adding this record");  
            },  
            error: function(response) {  
                alert("There was an unexpected error updating / adding this record");  
            }  
        });  
    }

function DeleteCourse() {
    var proceed = confirm("You are about to delete this student. Continue?");
    if (proceed) {
        var courseObject = new Object();
        courseObject.CourseListId = $("#CourseListId").val();

        $.ajax({
            type: "POST",
            url: window.student.Urls.DeleteCourse,
            data: JSON.stringify(courseObject),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(response) {
                if (response) {
                    if (response.value) {
                        if (response.value.success === true) {
                            alert("Course deleted successfully.");
                            location.reload();
                        }
                    } else {
                        alert("Something went wrong");
                    }
                } else {
                    alert("Something went wrong");
                }
            },
            failure: function(response) {
                alert("There was an unexpected error");
            },
            error: function(response) {
                alert("There was an unexpected error");
            }
        });
    }
}


function CloseMessage() {
    $("#modalMessage").modal("hide");
}


function CreateUL(array) {
    // Create the list element:
    var list = document.createElement("ul");
    for (var i = 0; i < array.length; i++) {
        // Create the list item:
        var item = document.createElement("li");
        // Set its contents:
        item.appendChild(document.createTextNode(array[i]));
        // Add it to the list:
        list.appendChild(item);
    }

    // Finally, return the constructed list:
    return list;
}
