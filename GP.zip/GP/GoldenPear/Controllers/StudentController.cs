﻿using System.Collections.Generic;
using System.Linq;
using GoldenPear.BLL.CourseServices;
using GoldenPear.BLL.StudentServices;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.BOL.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace GoldenPear.UI.Controllers
{
    public class StudentController: Controller
    {
        private readonly IStudent _studentService;
        private readonly ICourse _courseService;
        private readonly StudentViewModel _viewModel;
        

        public StudentController(IStudent studentService, ICourse courseService)
        {
            _studentService = studentService;
            _courseService = courseService;
            _viewModel = new StudentViewModel();
        }

        public IActionResult Index(string currentFilter, string searchString, int? page)
        {
            ViewData["CurrentFilter"] = searchString;
            _viewModel.Students = _studentService.GetPaginatedStudents(currentFilter, searchString, page);
            return View(_viewModel);
        }

        [HttpGet]
        public IActionResult Details(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                var success = int.TryParse(id, out var studentId);
                if (success)
                {
                    _viewModel.Student = _studentService.GetStudent(studentId);
                    _viewModel.StudentCoursesList = _studentService.GetStudentCourses(studentId);
                    if (_viewModel.Student != null)
                    {
                        return PartialView("Details", _viewModel);
                    }
                }

                return null;
            }
            _viewModel.Student = new Students();
            _viewModel.StudentCoursesList = _courseService.GetStudentCourseList();
            return PartialView("Details", _viewModel);
        }


        [HttpPost]
        [ActionName("UpdateStudent")]
        public JsonResult UpdateStudent([FromBody] Students student)
        {
            JsonResult response;
            if (ModelState.IsValid)
            {
                var retVal = student.StudentId > 0 ? _studentService.EditStudent(student) : _studentService.AddStudent(student);
                response = Json(new {success = retVal > -1, studentId = retVal});
            }
            else
            {
                response = Json(new {success = false,  student, errors = ModelState.Values.Where(i => i.Errors.Count > 0)});
            }

            return Json(response);
        }

        [HttpPost]
        [ActionName("DeleteStudent")]
        public JsonResult DeleteStudent([FromBody] object student)
        {
            var studentObject = JsonConvert.DeserializeObject<Students>(student.ToString());
            var retVal =  _studentService.DeleteStudent(studentObject.StudentId);
            var response = Json(new {success = retVal > -1});
            return Json(response);
        }


        [HttpPost]
        [ActionName("UpdateStudentCourses")]
        public JsonResult UpdateStudentCourses([FromBody] object studentCourses)
        {
            JsonResult response;


            var studentCourseList = JsonConvert.DeserializeObject<IEnumerable<StudentCourseList>>(studentCourses.ToString()).ToList();
            if (_courseService.SaveStudentCourses(studentCourseList.ToList()) > 0)
            {
                _viewModel.Student= _studentService.GetStudent(studentCourseList.Select(x => x.StudentId).FirstOrDefault());
                response = Json(new {success = true, studentName =  _viewModel.Student.FirstName + " " + _viewModel.Student.LastName});
            }
            else
            {
                response = Json(new {success = false});
            }


            return Json(response);
        }
    }
}
