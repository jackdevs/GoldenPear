﻿using System.Linq;
using GoldenPear.BLL.CourseServices;
using GoldenPear.BOL.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace GoldenPear.UI.Controllers
{
    public class CourseController : Controller
    {
        private readonly ICourse _courseService;

        
        public CourseController(ICourse courseService)
        {
            _courseService = courseService;
        }

        public IActionResult Index(string currentFilter, string searchString, int? page)
        {
            ViewData["CurrentFilter"] = searchString;
            var courses = _courseService.GetPaginatedCourseList(currentFilter, searchString, page);
            return View(courses);
        }

            [HttpGet]
        public IActionResult Details(string id)
        {
            if (!string.IsNullOrEmpty(id))
            {
                var success = int.TryParse(id, out var courseListId);
                if (success)
                {
                    
                    var courses = _courseService.GetCourse(courseListId);
                    if (courses != null)
                    {
                        return PartialView("Details", courses);
                    }
                }

                return null;
            }
            var newCourse = new CourseList();
            return PartialView("Details", newCourse);
        }


        [HttpPost]
        [ActionName("UpdateCourse")]
        public JsonResult UpdateCourse([FromBody] CourseList course)
        {
            JsonResult response;
            if (ModelState.IsValid)
            {
                var retVal = course.CourseListId > 0 ? _courseService.EditCourse(course) : _courseService.AddCourse(course);
                response = Json(new {success = retVal > -1, course.CourseName});
            }
            else
            {
                response = Json(new {success = false,  course, errors = ModelState.Values.Where(i => i.Errors.Count > 0)});
            }

            return Json(response);
        }

        [HttpPost]
        [ActionName("DeleteCourse")]
        public JsonResult DeleteCourse([FromBody] object courseList)
        {
            var courseObject = JsonConvert.DeserializeObject<CourseList>(courseList.ToString());
            var retVal =  _courseService.DeleteCourse(courseObject.CourseListId);
            var response = Json(new {success = retVal > -1});
            return Json(response);
        }


     
    }
}
