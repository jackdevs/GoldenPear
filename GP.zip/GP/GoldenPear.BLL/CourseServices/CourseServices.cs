﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.Common;
using GoldenPear.DAL.UnitOfWork;
using Microsoft.EntityFrameworkCore;

namespace GoldenPear.BLL.CourseServices
{
    public class CourseServices : ICourse
    {

        private readonly IUnitOfWork _unitOfWork;
        private const int PageSize = 10;
        public CourseServices(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public IEnumerable<CourseList> GetCourseList()
        {
            return _unitOfWork.CourseListRepository.Get();
        }

        public PaginatedList<CourseList> GetPaginatedCourseList(string currentFilter, string searchString, int? page)
        {
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            var courses = _unitOfWork.CourseListRepository.Get().AsQueryable();
            if (!string.IsNullOrEmpty(searchString))
            {
                courses = courses.Where(u => u.CourseName.ToLower().Trim().Contains(searchString.ToLower()));
            }

            return PaginatedList<CourseList>.Create(courses.AsNoTracking(), page ?? 1, PageSize);
        }

        public CourseList GetCourse(int id)
        {
            return _unitOfWork.CourseListRepository.GetFirstOrDefault(x => x.CourseListId == id);
        }

        public IEnumerable<Courses> GetStudentCourses(int id)
        {
            return _unitOfWork.CourseRepository.Get(x => x.StudentId == id);
        }

        public IEnumerable<StudentCourseList> GetStudentCourseList()
        {
            var studentCourses = GetCourseList();
            var studentCourseList = new List<StudentCourseList>();
            foreach (var studentCourse in studentCourses)
            {
                var cb = new StudentCourseList
                {
                    StudentId = -1,
                    CourseName = studentCourse.CourseName,
                    CourseListId = studentCourse.CourseListId,
                    Selected = false
                };
                studentCourseList.Add(cb);
            }

            return studentCourseList;
        }

        public int SaveStudentCourses(IEnumerable<StudentCourseList> studentCourses)
        {
            var studentId = studentCourses.FirstOrDefault().StudentId;
            try
            {
                
                foreach (var studentCourse in studentCourses)
                {

                    var courseListId = studentCourse.CourseListId;

                    var selected = studentCourse.Selected;
                   // studentId = studentCourse.StudentId;
                    var studentsInCourses = new Courses();

                    var id = studentId;

                    if (_unitOfWork.CourseRepository.Get().Any(x => x.StudentId == id && x.CourseListId == courseListId))
                    {
                        if (!selected)
                        {
                            var courseId = _unitOfWork.CourseRepository.GetFirstOrDefault(x => x.StudentId == id && x.CourseListId == courseListId).CourseId;
                            _unitOfWork.CourseRepository.Delete(courseId);
                        }
                    }
                    else
                    {
                        if (selected)
                        {
                            studentsInCourses.StudentId = studentId;
                            studentsInCourses.CourseListId = courseListId;
                            studentsInCourses.DateCreated = DateTime.Now;
                            studentsInCourses.CreatedBy = "jrossi";
                            _unitOfWork.CourseRepository.Insert(studentsInCourses);
                        }
                    }
                }

                _unitOfWork.Save();
            } 
            catch
            {
                return -1;
            }

            return studentId;
        }

        public int EditCourse(CourseList course)
        {
            try
            {
                var courseToUpdate = GetCourse(course.CourseListId);

                courseToUpdate.CourseName = course.CourseName;
                _unitOfWork.CourseListRepository.Update(courseToUpdate);
                _unitOfWork.Save();
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
                //return -1;
            }

            return course.CourseListId;
        }

        public int AddCourse(CourseList course)
        {
            try
            {
                _unitOfWork.CourseListRepository.Insert(course);
                _unitOfWork.Save();
            }
            catch 
            {
                return -1;
            }

            return course.CourseListId;
        }

        public int DeleteCourse(int id)
        {
            try
            {
                _unitOfWork.CourseListRepository.Delete(id);
                _unitOfWork.Save();
            }
            catch 
            {
                return -1;
            }

            return id;

        }
    }
}
