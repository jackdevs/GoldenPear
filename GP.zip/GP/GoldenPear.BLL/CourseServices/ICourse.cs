﻿using System.Collections.Generic;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.Common;

namespace GoldenPear.BLL.CourseServices
{
    public interface ICourse
    {
        IEnumerable<CourseList> GetCourseList();

        PaginatedList<CourseList> GetPaginatedCourseList(string currentFilter, string searchString, int? page);

        CourseList GetCourse(int id);

        IEnumerable<Courses> GetStudentCourses(int id);
        IEnumerable<StudentCourseList> GetStudentCourseList();
        
        int SaveStudentCourses(IEnumerable<StudentCourseList> studentCourses);

        int EditCourse(CourseList course);
        int AddCourse(CourseList course);
        int DeleteCourse(int id);



    }
}
