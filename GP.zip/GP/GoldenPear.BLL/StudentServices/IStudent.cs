﻿using System.Collections.Generic;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.Common;

namespace GoldenPear.BLL.StudentServices
{
     public interface IStudent
    {
        PaginatedList<Students> GetPaginatedStudents(string currentFilter, string searchString, int? page);

        Students GetStudent(int id);

        IEnumerable<StudentCourseList> GetStudentCourses(int id);

        int EditStudent(Students student);
        int AddStudent(Students student);
        int DeleteStudent(int id);

    }
}
