﻿using System;
using System.Collections.Generic;
using System.Linq;
using GoldenPear.BLL.CourseServices;
using GoldenPear.BOL.Dto;
using GoldenPear.BOL.Models;
using GoldenPear.Common;
using GoldenPear.DAL.UnitOfWork;
using Microsoft.EntityFrameworkCore;

namespace GoldenPear.BLL.StudentServices
{
    public class StudentServices : IStudent
    {
        private readonly IUnitOfWork _unitOfWork;
        private const int PageSize = 10;
        private readonly ICourse _courseService;

        public StudentServices(IUnitOfWork unitOfWork, ICourse courseService)
        {
            _unitOfWork = unitOfWork;
            _courseService = courseService;
        }
        public PaginatedList<Students> GetPaginatedStudents(string currentFilter, string searchString, int? page)
        {
            if (searchString != null)
            {
                page = 1;
            }
            else
            {
                searchString = currentFilter;
            }
            var students = _unitOfWork.StudentRepository.Get().AsQueryable();
            if (!string.IsNullOrEmpty(searchString))
            {
                students = students.Where(u => u.LastName.ToLower().Trim().Contains(searchString.ToLower()));
            }

            return PaginatedList<Students>.Create(students.AsNoTracking(), page ?? 1, PageSize);
        }

        public Students GetStudent(int id)
        {
            return _unitOfWork.StudentRepository.GetFirstOrDefault(x => x.StudentId == id);
        }

        public IEnumerable<StudentCourseList> GetStudentCourses(int id)
        {
            var studentCourseList = new List<StudentCourseList>();
            var student = GetStudent(id);
            var allCourses = _courseService.GetCourseList();
            var studentCourses = _courseService.GetStudentCourses(id).ToList();
            foreach (var course in allCourses)
            {
                var cb = new StudentCourseList
                {
                    StudentId = student.StudentId,
                    CourseName = course.CourseName,
                    CourseListId = course.CourseListId,
                    Selected = studentCourses.Any(x => x.CourseListId == course.CourseListId)
                };
                studentCourseList.Add(cb);
            }

            return studentCourseList;
        }

        public int EditStudent(Students student)
        {
            try
            {
                var studentToUpdate = GetStudent(student.StudentId);
                studentToUpdate.FirstName = student.FirstName;
                studentToUpdate.LastName = student.LastName;
                studentToUpdate.Grade = student.Grade;
                studentToUpdate.Major = student.Major;
                studentToUpdate.DateUpdated = DateTime.Now;
                studentToUpdate.UpdatedBy = "Mark";
                _unitOfWork.StudentRepository.Update(studentToUpdate);
                _unitOfWork.Save();
            }
            catch
            {
                return -1;
            }

            return student.StudentId;
        }

        public int AddStudent(Students student)
        {
            try
            {
                _unitOfWork.StudentRepository.Insert(student);
                _unitOfWork.Save();
            }
            catch 
            {
                return -1;
            }

            return student.StudentId;
        }

        public int DeleteStudent(int id)
        {
            try
            {
                _unitOfWork.StudentRepository.Delete(id);
                
                var studentCourses = _courseService.GetStudentCourses(id).ToList();
                foreach (var courses in studentCourses)
                {
                    var courseId = courses.CourseId;
                    _unitOfWork.CourseRepository.Delete(courseId);
                }

                _unitOfWork.Save();
            }
            catch
            {
                return -1;
            }

            return id;
        }
    }
}
